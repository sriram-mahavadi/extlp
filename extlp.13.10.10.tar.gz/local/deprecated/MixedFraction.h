/* 
 * File:   MixedFraction.h
 * Author: sriram
 *
 * Created on 13 March, 2014, 5:27 PM
 */

#ifndef MIXEDFRACTION_H
#define	MIXEDFRACTION_H
#include "Fraction.h"
class MixedFraction{
    int quotient;
    Fraction fraction;
    
    MixedFraction(){
        
    }
};


#endif	/* MIXEDFRACTION_H */

