/* 
 * File:   ReadLPUtil.h
 * Author: sriram
 *
 * Created on 6 April, 2014, 1:37 AM
 */

#ifndef READLPUTIL_H
#define	READLPUTIL_H

#include "../ExtLPDSSet.h"
#include "../GlobalDefines.h"
class ReadLPUtil {
public:
//    bool readLPF(std::istream &is) {
//        CONSOLE_PRINTLN("Reading lpf file\n");
//        return false;
//    }
};

#endif	/* READLPUTIL_H */

